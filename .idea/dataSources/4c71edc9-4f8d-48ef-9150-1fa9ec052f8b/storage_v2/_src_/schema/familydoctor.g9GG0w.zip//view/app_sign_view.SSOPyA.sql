create view app_sign_view as (select `t`.`PATIENT_IDNO`                                  AS `PATIENT_IDNO`,
                                     `t`.`PATIENT_NAME`                                  AS `PATIENT_NAME`,
                                     `t`.`PATIENT_JMDA`                                  AS `PATIENT_JMDA`,
                                     `d`.`SIGN_FROM_DATE`                                AS `SIGN_FROM_DATE`,
                                     `d`.`SIGN_TO_DATE`                                  AS `SIGN_TO_DATE`,
                                     `d`.`SIGN_HOSP_ID`                                  AS `SIGN_HOSP_ID`,
                                     `d`.`SIGN_AREA_CODE`                                AS `SIGN_AREA_CODE`,
                                     (select `g`.`LEVEL_NAME`
                                      from `familydoctor`.`cp_city_area` `g`
                                      where (`g`.`CITY_AREA_ID` = `d`.`SIGN_AREA_CODE`)) AS `SIGN_AREA_LEVEL`,
                                     (select group_concat(`f`.`LABEL_TITLE` separator ',')
                                      from `familydoctor`.`app_label_group` `f`
                                      where (`f`.`LABEL_SIGN_ID` = `d`.`ID`))            AS `SIGN_GROUP`
                              from (`familydoctor`.`app_patient_user` `t`
                                     join `familydoctor`.`app_sign_form` `d` on ((`t`.`ID` = `d`.`SIGN_PATIENT_ID`)))
                              where ((1 = 1) and (`d`.`SIGN_STATE` in ('0', '2'))));

